package com.example.idgs_9a11_sd_24_a2p2_navdrawer.ui.bondeddevices;

import androidx.lifecycle.ViewModel;

public class BondedDevicesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}