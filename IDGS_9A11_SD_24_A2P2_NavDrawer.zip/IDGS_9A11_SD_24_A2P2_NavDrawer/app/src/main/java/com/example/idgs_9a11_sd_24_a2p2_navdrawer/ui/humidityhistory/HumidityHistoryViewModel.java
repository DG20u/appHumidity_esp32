package com.example.idgs_9a11_sd_24_a2p2_navdrawer.ui.humidityhistory;

import androidx.lifecycle.ViewModel;

public class HumidityHistoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}